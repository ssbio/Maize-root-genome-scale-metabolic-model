initCobraToolbox()
model9 = xls2model('test_zeamr.xlsx')
FBASolution = optimizeCbModel(model9)